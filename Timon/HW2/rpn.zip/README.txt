You can compile the code with "dune build rpn.exe"
You can test the code with "./_build/default/rpn.exe < test.txt"

The expected results are stored in test.txt.
All functionality works as expected.
Besides the specifications, no extra assumptions were made.
Make sure to hit Ctrl+C to end the program. 
To type your own calculations, run the program with "./_build/default/rpn.exe"